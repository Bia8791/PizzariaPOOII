package br.unicentro.apppizzaria.strategy;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class DescontoQuantidadeTest {

    @Test
    void calculaDescontoAoComprarCincoPizzas() {
        DescontoQuantidade desconto = new DescontoQuantidade();

        assertEquals(135.0, desconto.calcular(30.0, 5), 0.001,
                "Cinco pizzas de R$ 30,00 devem totalizar R$ 135,00 com desconto de 10%.");
        assertEquals(120.0, desconto.calcular(30.0, 4), 0.001,
                "Quatro pizzas devem manter o valor sem desconto.");
    }
}
