package br.unicentro.apppizzaria.service;

import br.unicentro.apppizzaria.dao.IPizzaDAO;
import br.unicentro.apppizzaria.model.Pizza;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class PizzaServiceTest {

    private static class PizzaDAOFake implements IPizzaDAO {
        int insercoes;
        final List<Pizza> pizzas = new ArrayList<>();

        @Override
        public void inseri(Pizza pizza) {
            insercoes++;
            pizzas.add(pizza);
        }

        @Override
        public void alteri(Pizza pizza) {}

        @Override
        public void exclui(int id) {}

        @Override
        public List<Pizza> buscarTodos() {
            return pizzas;
        }
    }

    @Test
    void cadastraPizzaValidaERejeitaPrecoInvalido() throws Exception {
        PizzaDAOFake dao = new PizzaDAOFake();
        PizzaService service = new PizzaService(dao);
        Pizza pizzaValida = new Pizza("Calabresa", "Calabresa e cebola", 40.0);

        service.salvar(pizzaValida);
        assertEquals(1, dao.insercoes,
                "Uma pizza válida deve ser encaminhada ao DAO para cadastro.");
        assertSame(pizzaValida, dao.pizzas.get(0),
                "O DAO deve receber a mesma pizza informada.");

        Pizza pizzaInvalida = new Pizza("Marguerita", "Tomate e queijo", 0.0);
        assertThrows(ServiceException.class, () -> service.salvar(pizzaInvalida),
                "O serviço deve rejeitar uma pizza com preço igual a zero.");
        assertEquals(1, dao.insercoes,
                "Uma pizza com preço inválido não deve ser inserida no DAO.");
    }
}
