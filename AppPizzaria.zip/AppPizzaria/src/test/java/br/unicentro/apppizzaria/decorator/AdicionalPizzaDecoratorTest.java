package br.unicentro.apppizzaria.decorator;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class AdicionalPizzaDecoratorTest {

    @Test
    void calculaPrecoComDoisAdicionais() {
        PrecoPizza pizza = new AdicionalPizzaDecorator(
                new PizzaBase(25.0), "Queijo, Bacon, , ");

        assertEquals(32.0, pizza.calcularPreco(), 0.001,
                "A pizza de R$ 25,00 com dois adicionais de R$ 3,50 deve custar R$ 32,00.");
    }
}
