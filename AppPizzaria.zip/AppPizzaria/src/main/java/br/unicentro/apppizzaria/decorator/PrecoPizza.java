package br.unicentro.apppizzaria.decorator;
public interface PrecoPizza { double calcularPreco(); }
