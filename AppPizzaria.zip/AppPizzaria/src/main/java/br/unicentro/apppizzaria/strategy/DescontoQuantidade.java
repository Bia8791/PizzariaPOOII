package br.unicentro.apppizzaria.strategy;

public class DescontoQuantidade implements PoliticaPreco {
    public double calcular(double valorUnitario, int quantidade) {
        double total = valorUnitario * quantidade;
        return quantidade >= 5 ? total * 0.90 : total;
    }
    public String descricao() { return "Desconto de 10% para 5 ou mais pizzas"; }
}
