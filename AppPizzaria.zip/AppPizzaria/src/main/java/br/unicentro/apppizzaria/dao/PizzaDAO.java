package br.unicentro.apppizzaria.dao;

import br.unicentro.apppizzaria.model.Pizza;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PizzaDAO implements IPizzaDAO {

    @Override
    public void inseri(Pizza pizza) throws Exception {
        String sql = "INSERT INTO pizza (nome, ingredientes, preco) VALUES (?, ?, ?)";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, pizza.getNome());
            ps.setString(2, pizza.getIngredientes());
            ps.setDouble(3, pizza.getPreco());
            ps.executeUpdate();
        }
    }

    @Override
    public void alteri(Pizza pizza) throws Exception {
        String sql = "UPDATE pizza SET nome=?, ingredientes=?, preco=? WHERE id=?";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, pizza.getNome());
            ps.setString(2, pizza.getIngredientes());
            ps.setDouble(3, pizza.getPreco());
            ps.setInt(4, pizza.getId());
            ps.executeUpdate();
        }
    }

    @Override
    public void exclui(int id) throws Exception {
        String sql = "DELETE FROM pizza WHERE id=?";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    @Override
    public List<Pizza> buscarTodos() throws Exception {
        List<Pizza> lista = new ArrayList<>();
        String sql = "SELECT * FROM pizza ORDER BY id";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Pizza p = new Pizza(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("ingredientes"),
                        rs.getDouble("preco")
                );
                lista.add(p);
            }
        }
        return lista;
    }
}
