package br.unicentro.apppizzaria.dao;

import br.unicentro.apppizzaria.model.Cliente;
import java.util.List;

public interface IClienteDAO {
    void inseri(Cliente cliente) throws Exception;
    void alteri(Cliente cliente) throws Exception;
    void exclui(int id) throws Exception;
    List<Cliente> buscarTodos() throws Exception;
}
