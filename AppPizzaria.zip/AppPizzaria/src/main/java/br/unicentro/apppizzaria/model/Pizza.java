package br.unicentro.apppizzaria.model;

public class Pizza {
    private int id;
    private String nome;
    private String ingredientes;
    private double preco;

    public Pizza() {}

    public Pizza(int id, String nome, String ingredientes, double preco) {
        this.id = id;
        this.nome = nome;
        this.ingredientes = ingredientes;
        this.preco = preco;
    }

    public Pizza(String nome, String ingredientes, double preco) {
        this.nome = nome;
        this.ingredientes = ingredientes;
        this.preco = preco;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getIngredientes() { return ingredientes; }
    public void setIngredientes(String ingredientes) { this.ingredientes = ingredientes; }
    public double getPreco() { return preco; }
    public void setPreco(double preco) { this.preco = preco; }

    @Override
    public String toString() {
        return nome + " - R$ " + preco;
    }
}
