package br.unicentro.apppizzaria.dao;

import br.unicentro.apppizzaria.model.Pedido;
import java.util.List;

public interface IPedidoDAO {
    void inseri(Pedido pedido) throws Exception;
    void alteri(Pedido pedido) throws Exception;
    void exclui(int id) throws Exception;
    List<Pedido> buscarTodos() throws Exception;
}
