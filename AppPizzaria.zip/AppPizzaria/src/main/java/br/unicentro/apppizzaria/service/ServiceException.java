package br.unicentro.apppizzaria.service;

public class ServiceException extends Exception {
    public ServiceException(String mensagem) { super(mensagem); }
}
