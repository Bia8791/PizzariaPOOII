package br.unicentro.apppizzaria.main;

import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
        GerenciadorTelas.setStage(primaryStage);
        primaryStage.setTitle("Sistema de Gerenciamento - Pizzaria");
        GerenciadorTelas.trocadeTela("Menus.fxml");
    }

    public static void main(String[] args) {
        launch(args);
    }
}
