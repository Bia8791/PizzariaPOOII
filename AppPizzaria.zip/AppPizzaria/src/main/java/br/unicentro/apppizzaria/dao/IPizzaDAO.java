package br.unicentro.apppizzaria.dao;

import br.unicentro.apppizzaria.model.Pizza;
import java.util.List;

public interface IPizzaDAO {
    void inseri(Pizza pizza) throws Exception;
    void alteri(Pizza pizza) throws Exception;
    void exclui(int id) throws Exception;
    List<Pizza> buscarTodos() throws Exception;
}
