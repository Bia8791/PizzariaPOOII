package br.unicentro.apppizzaria.controller;

import br.unicentro.apppizzaria.dao.PizzaDAO;
import br.unicentro.apppizzaria.main.GerenciadorTelas;
import br.unicentro.apppizzaria.model.Pizza;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class PizzaController {
    @FXML private TextField txtNome;
    @FXML private TextField txtIngredientes;
    @FXML private TextField txtPreco;
    @FXML private TableView<Pizza> tablePizzas;
    @FXML private TableColumn<Pizza, Integer> colId;
    @FXML private TableColumn<Pizza, String> colNome;
    @FXML private TableColumn<Pizza, String> colIngredientes;
    @FXML private TableColumn<Pizza, Double> colPreco;

    private final PizzaDAO pizzaDAO = new PizzaDAO();
    private Pizza pizzaSelecionada;

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colIngredientes.setCellValueFactory(new PropertyValueFactory<>("ingredientes"));
        colPreco.setCellValueFactory(new PropertyValueFactory<>("preco"));
        carregarTabela();

        tablePizzas.getSelectionModel().selectedItemProperty().addListener((obs, antigo, atual) -> {
            if (atual != null) {
                pizzaSelecionada = atual;
                txtNome.setText(atual.getNome());
                txtIngredientes.setText(atual.getIngredientes());
                txtPreco.setText(String.valueOf(atual.getPreco()));
            }
        });
    }

    private void carregarTabela() {
        try {
            tablePizzas.setItems(FXCollections.observableArrayList(pizzaDAO.buscarTodos()));
        } catch (Exception e) {
            Aviso.erro("Falha ao carregar pizzas. Confira a conexão com o PostgreSQL.\n" + e.getMessage());
        }
    }

    @FXML
    public void salvar() {
        String nome = txtNome.getText().trim();
        String ingredientes = txtIngredientes.getText().trim();
        double preco;
        if (nome.isEmpty() || ingredientes.isEmpty() || txtPreco.getText().trim().isEmpty()) {
            Aviso.erro("Preencha o nome, os ingredientes e o preço.");
            return;
        }
        try {
            preco = Double.parseDouble(txtPreco.getText().trim().replace(",", "."));
            if (preco <= 0) {
                Aviso.erro("O preço deve ser maior que zero.");
                return;
            }
            if (pizzaSelecionada == null) {
                pizzaDAO.inseri(new Pizza(nome, ingredientes, preco));
                Aviso.mostrar("Sucesso", "Pizza cadastrada.");
            } else {
                pizzaSelecionada.setNome(nome);
                pizzaSelecionada.setIngredientes(ingredientes);
                pizzaSelecionada.setPreco(preco);
                pizzaDAO.alteri(pizzaSelecionada);
                Aviso.mostrar("Sucesso", "Pizza atualizada.");
            }
            limparCampos();
            carregarTabela();
        } catch (NumberFormatException e) {
            Aviso.erro("Digite um preço válido. Exemplo: 35,90.");
        } catch (Exception e) {
            Aviso.erro("Não foi possível salvar a pizza.\n" + e.getMessage());
        }
    }

    @FXML
    public void excluir() {
        if (pizzaSelecionada == null) {
            Aviso.erro("Selecione uma pizza na tabela para excluir.");
            return;
        }
        try {
            pizzaDAO.exclui(pizzaSelecionada.getId());
            limparCampos();
            carregarTabela();
            Aviso.mostrar("Sucesso", "Pizza excluída.");
        } catch (Exception e) {
            Aviso.erro("Não foi possível excluir esta pizza. Verifique se ela está vinculada a algum pedido.\n" + e.getMessage());
        }
    }

    @FXML
    public void limparCampos() {
        pizzaSelecionada = null;
        tablePizzas.getSelectionModel().clearSelection();
        txtNome.clear();
        txtIngredientes.clear();
        txtPreco.clear();
    }

    @FXML
    public void voltar() {
        GerenciadorTelas.trocadeTela("Menus.fxml");
    }
}
