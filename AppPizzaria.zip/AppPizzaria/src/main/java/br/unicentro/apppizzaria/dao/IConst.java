package br.unicentro.apppizzaria.dao;

public interface IConst {
    String URL = "jdbc:postgresql://localhost:5432/pizzariaBeatriz";
    String USER = "postgres";
    String PWD = "1234";
    String DRIVER = "org.postgresql.Driver";
}
