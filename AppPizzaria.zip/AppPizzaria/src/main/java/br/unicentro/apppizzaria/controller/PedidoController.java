package br.unicentro.apppizzaria.controller;

import br.unicentro.apppizzaria.dao.ClienteDAO;
import br.unicentro.apppizzaria.dao.PedidoDAO;
import br.unicentro.apppizzaria.dao.PizzaDAO;
import br.unicentro.apppizzaria.main.GerenciadorTelas;
import br.unicentro.apppizzaria.model.Cliente;
import br.unicentro.apppizzaria.model.Pedido;
import br.unicentro.apppizzaria.model.Pizza;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class PedidoController {
    @FXML private ComboBox<Cliente> cbCliente;
    @FXML private ComboBox<Pizza> cbPizza;
    @FXML private TextField txtQuantidade;
    @FXML private Label lblValorTotal;
    @FXML private TextField txtStatus;
    @FXML private TableView<Pedido> tablePedidos;
    @FXML private TableColumn<Pedido, Integer> colId;
    @FXML private TableColumn<Pedido, Integer> colCliente;
    @FXML private TableColumn<Pedido, Integer> colPizza;
    @FXML private TableColumn<Pedido, Integer> colQuantidade;
    @FXML private TableColumn<Pedido, Double> colValorTotal;
    @FXML private TableColumn<Pedido, String> colStatus;

    private final PedidoDAO pedidoDAO = new PedidoDAO();
    private final ClienteDAO clienteDAO = new ClienteDAO();
    private final PizzaDAO pizzaDAO = new PizzaDAO();
    private Pedido pedidoSelecionado;

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colCliente.setCellValueFactory(new PropertyValueFactory<>("clienteId"));
        colPizza.setCellValueFactory(new PropertyValueFactory<>("pizzaId"));
        colQuantidade.setCellValueFactory(new PropertyValueFactory<>("quantidade"));
        colValorTotal.setCellValueFactory(new PropertyValueFactory<>("valorTotal"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        cbPizza.valueProperty().addListener((obs, antigo, atual) -> calcularTotal());
        txtQuantidade.textProperty().addListener((obs, antigo, atual) -> calcularTotal());
        carregarCombos();
        carregarTabela();

        tablePedidos.getSelectionModel().selectedItemProperty().addListener((obs, antigo, atual) -> {
            if (atual != null) {
                pedidoSelecionado = atual;
                cbCliente.getItems().stream().filter(c -> c.getId() == atual.getClienteId()).findFirst().ifPresent(cbCliente::setValue);
                cbPizza.getItems().stream().filter(p -> p.getId() == atual.getPizzaId()).findFirst().ifPresent(cbPizza::setValue);
                txtQuantidade.setText(String.valueOf(atual.getQuantidade()));
                lblValorTotal.setText(String.format(java.util.Locale.forLanguageTag("pt-BR"), "R$ %.2f", atual.getValorTotal()));
                txtStatus.setText(atual.getStatus());
            }
        });
    }

    private void carregarCombos() {
        try {
            cbCliente.setItems(FXCollections.observableArrayList(clienteDAO.buscarTodos()));
            cbPizza.setItems(FXCollections.observableArrayList(pizzaDAO.buscarTodos()));
        } catch (Exception e) {
            Aviso.erro("Não foi possível carregar clientes e pizzas.\n" + e.getMessage());
        }
    }

    private void carregarTabela() {
        try {
            tablePedidos.setItems(FXCollections.observableArrayList(pedidoDAO.buscarTodos()));
        } catch (Exception e) {
            Aviso.erro("Não foi possível carregar pedidos.\n" + e.getMessage());
        }
    }

    @FXML
    public void calcularTotal() {
        try {
            Pizza pizza = cbPizza.getValue();
            int quantidade = Integer.parseInt(txtQuantidade.getText().trim());
            if (pizza != null && quantidade > 0) {
                lblValorTotal.setText(String.format(java.util.Locale.forLanguageTag("pt-BR"), "R$ %.2f", pizza.getPreco() * quantidade));
                return;
            }
        } catch (NumberFormatException ignored) {
        }
        lblValorTotal.setText("R$ 0,00");
    }

    @FXML
    public void salvar() {
        Cliente cliente = cbCliente.getValue();
        Pizza pizza = cbPizza.getValue();
        if (cliente == null || pizza == null) {
            Aviso.erro("Selecione um cliente e uma pizza.");
            return;
        }

        int quantidade;
        try {
            quantidade = Integer.parseInt(txtQuantidade.getText().trim());
            if (quantidade <= 0) {
                Aviso.erro("A quantidade deve ser maior que zero.");
                return;
            }
        } catch (NumberFormatException e) {
            Aviso.erro("Digite uma quantidade inteira válida.");
            return;
        }

        String status = txtStatus.getText().trim();
        if (status.isEmpty()) status = "Em Andamento";
        if (status.length() > 30) {
            Aviso.erro("O status deve ter no máximo 30 caracteres.");
            return;
        }

        double total = pizza.getPreco() * quantidade;
        try {
            if (pedidoSelecionado == null) {
                pedidoDAO.inseri(new Pedido(cliente.getId(), pizza.getId(), quantidade, total, status));
                Aviso.mostrar("Sucesso", "Pedido cadastrado.");
            } else {
                pedidoSelecionado.setClienteId(cliente.getId());
                pedidoSelecionado.setPizzaId(pizza.getId());
                pedidoSelecionado.setQuantidade(quantidade);
                pedidoSelecionado.setValorTotal(total);
                pedidoSelecionado.setStatus(status);
                pedidoDAO.alteri(pedidoSelecionado);
                Aviso.mostrar("Sucesso", "Pedido atualizado.");
            }
            limparCampos();
            carregarTabela();
        } catch (Exception e) {
            Aviso.erro("Não foi possível salvar o pedido.\n" + e.getMessage());
        }
    }

    @FXML
    public void excluir() {
        if (pedidoSelecionado == null) {
            Aviso.erro("Selecione um pedido na tabela para excluir.");
            return;
        }
        try {
            pedidoDAO.exclui(pedidoSelecionado.getId());
            limparCampos();
            carregarTabela();
            Aviso.mostrar("Sucesso", "Pedido excluído.");
        } catch (Exception e) {
            Aviso.erro("Não foi possível excluir o pedido.\n" + e.getMessage());
        }
    }

    @FXML
    public void limparCampos() {
        pedidoSelecionado = null;
        tablePedidos.getSelectionModel().clearSelection();
        cbCliente.setValue(null);
        cbPizza.setValue(null);
        txtQuantidade.clear();
        lblValorTotal.setText("R$ 0,00");
        txtStatus.clear();
    }

    @FXML
    public void voltar() {
        GerenciadorTelas.trocadeTela("Menus.fxml");
    }
}
