package br.unicentro.apppizzaria.controller;

import br.unicentro.apppizzaria.dao.ClienteDAO;
import br.unicentro.apppizzaria.main.GerenciadorTelas;
import br.unicentro.apppizzaria.model.Cliente;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class ClienteController {
    @FXML private TextField txtNome;
    @FXML private TextField txtTelefone;
    @FXML private TextField txtEndereco;
    @FXML private TableView<Cliente> tableClientes;
    @FXML private TableColumn<Cliente, Integer> colId;
    @FXML private TableColumn<Cliente, String> colNome;
    @FXML private TableColumn<Cliente, String> colTelefone;
    @FXML private TableColumn<Cliente, String> colEndereco;

    private final ClienteDAO clienteDAO = new ClienteDAO();
    private Cliente clienteSelecionado;

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colTelefone.setCellValueFactory(new PropertyValueFactory<>("telefone"));
        colEndereco.setCellValueFactory(new PropertyValueFactory<>("endereco"));
        carregarTabela();

        tableClientes.getSelectionModel().selectedItemProperty().addListener((obs, antigo, atual) -> {
            if (atual != null) {
                clienteSelecionado = atual;
                txtNome.setText(atual.getNome());
                txtTelefone.setText(atual.getTelefone());
                txtEndereco.setText(atual.getEndereco());
            }
        });
    }

    private void carregarTabela() {
        try {
            tableClientes.setItems(FXCollections.observableArrayList(clienteDAO.buscarTodos()));
        } catch (Exception e) {
            Aviso.erro("Falha ao carregar clientes. Confira se o PostgreSQL está ativo e a conexão está correta.\n" + e.getMessage());
        }
    }

    @FXML
    public void salvar() {
        String nome = txtNome.getText().trim();
        String telefone = txtTelefone.getText().trim();
        String endereco = txtEndereco.getText().trim();

        if (nome.isEmpty() || telefone.isEmpty() || endereco.isEmpty()) {
            Aviso.erro("Preencha nome, telefone e endereço.");
            return;
        }

        try {
            if (clienteSelecionado == null) {
                clienteDAO.inseri(new Cliente(nome, telefone, endereco));
                Aviso.mostrar("Sucesso", "Cliente cadastrado.");
            } else {
                clienteSelecionado.setNome(nome);
                clienteSelecionado.setTelefone(telefone);
                clienteSelecionado.setEndereco(endereco);
                clienteDAO.alteri(clienteSelecionado);
                Aviso.mostrar("Sucesso", "Cliente atualizado.");
            }
            limparCampos();
            carregarTabela();
        } catch (Exception e) {
            Aviso.erro("Não foi possível salvar o cliente. Se ele possuir pedidos, não poderá ser excluído.\n" + e.getMessage());
        }
    }

    @FXML
    public void excluir() {
        if (clienteSelecionado == null) {
            Aviso.erro("Selecione um cliente na tabela para excluir.");
            return;
        }
        try {
            clienteDAO.exclui(clienteSelecionado.getId());
            limparCampos();
            carregarTabela();
            Aviso.mostrar("Sucesso", "Cliente excluído.");
        } catch (Exception e) {
            Aviso.erro("Não foi possível excluir. Verifique se existem pedidos vinculados a este cliente.\n" + e.getMessage());
        }
    }

    @FXML
    public void limparCampos() {
        clienteSelecionado = null;
        tableClientes.getSelectionModel().clearSelection();
        txtNome.clear();
        txtTelefone.clear();
        txtEndereco.clear();
    }

    @FXML
    public void voltar() {
        GerenciadorTelas.trocadeTela("Menus.fxml");
    }
}
