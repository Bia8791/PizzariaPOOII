package br.unicentro.apppizzaria.strategy;

public interface PoliticaPreco {
    double calcular(double valorUnitario, int quantidade); String descricao();
}
