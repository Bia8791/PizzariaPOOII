package br.unicentro.apppizzaria.controller;

import javafx.scene.control.Alert;

public class Aviso {
    public static void mostrar(String titulo, String mensagem) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensagem);
        alerta.showAndWait();
    }

    public static void erro(String mensagem) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("Erro");
        alerta.setHeaderText("Não foi possível concluir a operação");
        alerta.setContentText(mensagem);
        alerta.showAndWait();
    }
}
