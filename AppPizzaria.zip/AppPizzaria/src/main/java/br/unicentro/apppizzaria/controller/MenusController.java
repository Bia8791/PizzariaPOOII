package br.unicentro.apppizzaria.controller;

import br.unicentro.apppizzaria.main.GerenciadorTelas;
import javafx.fxml.FXML;

public class MenusController {

    @FXML
    public void abrirClientes() {
        GerenciadorTelas.trocadeTela("Cliente.fxml");
    }

    @FXML
    public void abrirPizzas() {
        GerenciadorTelas.trocadeTela("Pizza.fxml");
    }

    @FXML
    public void abrirPedidos() {
        GerenciadorTelas.trocadeTela("Pedido.fxml");
    }
}
