package br.unicentro.apppizzaria.dao;

import br.unicentro.apppizzaria.model.Pedido;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PedidoDAO implements IPedidoDAO {

    @Override
    public void inseri(Pedido pedido) throws Exception {
        String sql = "INSERT INTO pedido (cliente_id, pizza_id, quantidade, valor_total, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, pedido.getClienteId());
            ps.setInt(2, pedido.getPizzaId());
            ps.setInt(3, pedido.getQuantidade());
            ps.setDouble(4, pedido.getValorTotal());
            ps.setString(5, pedido.getStatus());
            ps.executeUpdate();
        }
    }

    @Override
    public void alteri(Pedido pedido) throws Exception {
        String sql = "UPDATE pedido SET cliente_id=?, pizza_id=?, quantidade=?, valor_total=?, status=? WHERE id=?";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, pedido.getClienteId());
            ps.setInt(2, pedido.getPizzaId());
            ps.setInt(3, pedido.getQuantidade());
            ps.setDouble(4, pedido.getValorTotal());
            ps.setString(5, pedido.getStatus());
            ps.setInt(6, pedido.getId());
            ps.executeUpdate();
        }
    }

    @Override
    public void exclui(int id) throws Exception {
        String sql = "DELETE FROM pedido WHERE id=?";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    @Override
    public List<Pedido> buscarTodos() throws Exception {
        List<Pedido> lista = new ArrayList<>();
        String sql = "SELECT * FROM pedido ORDER BY id";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Pedido p = new Pedido(
                        rs.getInt("id"),
                        rs.getInt("cliente_id"),
                        rs.getInt("pizza_id"),
                        rs.getInt("quantidade"),
                        rs.getDouble("valor_total"),
                        rs.getString("status")
                );
                lista.add(p);
            }
        }
        return lista;
    }
}
