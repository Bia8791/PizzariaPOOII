module br.unicentro.apppizzaria {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires org.postgresql.jdbc;

    opens br.unicentro.apppizzaria.controller to javafx.fxml;
    opens br.unicentro.apppizzaria.model to javafx.base;
    exports br.unicentro.apppizzaria.main;
}
