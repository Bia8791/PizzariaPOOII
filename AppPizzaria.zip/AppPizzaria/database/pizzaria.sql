CREATE TABLE cliente (
                         id SERIAL PRIMARY KEY,
                         nome VARCHAR(100) NOT NULL,
                         telefone VARCHAR(20) NOT NULL,
                         endereco VARCHAR(200) NOT NULL
);

CREATE TABLE pizza (
                       id SERIAL PRIMARY KEY,
                       nome VARCHAR(100) NOT NULL,
                       ingredientes TEXT NOT NULL,
                       preco NUMERIC(10,2) NOT NULL
);

CREATE TABLE pedido (
                        id SERIAL PRIMARY KEY,
                        cliente_id INTEGER NOT NULL,
                        pizza_id INTEGER NOT NULL,
                        quantidade INTEGER NOT NULL,
                        valor_total NUMERIC(10,2) NOT NULL,
                        status VARCHAR(30) NOT NULL,
                        FOREIGN KEY (cliente_id) REFERENCES cliente(id),
                        FOREIGN KEY (pizza_id) REFERENCES pizza(id)
);