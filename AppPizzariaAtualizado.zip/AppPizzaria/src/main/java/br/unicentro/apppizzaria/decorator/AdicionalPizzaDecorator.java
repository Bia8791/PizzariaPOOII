package br.unicentro.apppizzaria.decorator;
/** Decorator concreto: acrescenta R$ 3,50 por adicional informado. */
public class AdicionalPizzaDecorator implements PrecoPizza {
    private final PrecoPizza pizza;
    private final int quantidadeAdicionais;
    private static final double PRECO_ADICIONAL = 3.50;
    public AdicionalPizzaDecorator(PrecoPizza pizza, String adicionais) {
        this.pizza = pizza;
        this.quantidadeAdicionais = contar(adicionais);
    }
    public double calcularPreco() { return pizza.calcularPreco()
            + quantidadeAdicionais * PRECO_ADICIONAL; }

    private int contar(String texto) {
        if (texto == null || texto.trim().isEmpty()) return 0;
        return (int) java.util.Arrays.stream(texto.split(","))
                .map(String::trim).filter(s -> !s.isEmpty()).count();
    }
}
