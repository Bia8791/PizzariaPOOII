package br.unicentro.apppizzaria.strategy;

/** Strategy: define uma política substituível para calcular o preço do pedido. */
public interface PoliticaPreco { double calcular(double valorUnitario, int quantidade); String descricao(); }
