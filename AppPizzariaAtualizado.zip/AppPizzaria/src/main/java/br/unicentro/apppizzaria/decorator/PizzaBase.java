package br.unicentro.apppizzaria.decorator;
public class PizzaBase implements PrecoPizza {
    private final double preco;
    public PizzaBase(double preco) { this.preco = preco; }
    public double calcularPreco() { return preco; }
}
