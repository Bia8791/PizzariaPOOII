package br.unicentro.apppizzaria.service;

/** Exceção para erros de validação e regras da camada de serviços. */
public class ServiceException extends Exception {
    public ServiceException(String mensagem) { super(mensagem); }
}
