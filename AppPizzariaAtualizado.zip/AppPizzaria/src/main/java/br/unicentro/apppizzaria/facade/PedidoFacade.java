package br.unicentro.apppizzaria.facade;

import br.unicentro.apppizzaria.model.*;
import br.unicentro.apppizzaria.service.*;
import br.unicentro.apppizzaria.decorator.*;
import br.unicentro.apppizzaria.strategy.*;

public class PedidoFacade {
    private final ClienteService clienteService;
    private final PizzaService pizzaService;
    private final PedidoService pedidoService;
    public PedidoFacade() { this(new ClienteService(), new PizzaService(), new PedidoService()); }
    public PedidoFacade(ClienteService cs, PizzaService ps, PedidoService os) {
        clienteService = cs; pizzaService = ps; pedidoService = os;
    }
    public java.util.List<Cliente> listarClientes() throws Exception { return clienteService.listar(); }
    public java.util.List<Pizza> listarPizzas() throws Exception { return pizzaService.listar(); }
    public java.util.List<Pedido> listarPedidos() throws Exception { return pedidoService.listar(); }
    public double calcularTotal(Pizza pizza, int quantidade, String adicionais) {
        if (pizza == null || quantidade <= 0) return 0;
        PrecoPizza preco = new PizzaBase(pizza.getPreco());
        preco = new AdicionalPizzaDecorator(preco, adicionais);
        PoliticaPreco politica = quantidade >= 5 ? new DescontoQuantidade() : new PrecoNormal();
        return politica.calcular(preco.calcularPreco(), quantidade);
    }
    public void salvarPedido(int id, int clienteId,
                             int pizzaId, int quantidade,
                             String status, String adicionais) throws Exception {
        Cliente cliente = clienteService.obter(clienteId);
        Pizza pizza = pizzaService.obter(pizzaId);
        double total = calcularTotal(pizza, quantidade, adicionais);
        Pedido pedido = new Pedido(id, cliente.getId(), pizza.getId(), quantidade, total, status);
        pedido.setAdicionais(adicionais == null ? "" : adicionais.trim());
        pedidoService.salvar(pedido);
    }
    public void excluirPedido(int id) throws Exception { pedidoService.excluir(id); }
}
