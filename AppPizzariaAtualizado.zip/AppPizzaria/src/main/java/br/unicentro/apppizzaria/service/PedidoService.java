package br.unicentro.apppizzaria.service;

import br.unicentro.apppizzaria.dao.IPedidoDAO;
import br.unicentro.apppizzaria.dao.PedidoDAO;
import br.unicentro.apppizzaria.model.Pedido;
import java.util.List;

/** Regras de negócio para persistência de pedidos. */
public class PedidoService {
    private final IPedidoDAO dao;
    public PedidoService() { this(new PedidoDAO()); }
    public PedidoService(IPedidoDAO dao) { this.dao = dao; }
    public List<Pedido> listar() throws Exception { return dao.buscarTodos(); }
    public void salvar(Pedido p) throws Exception {
        if (p == null || p.getClienteId() <= 0 || p.getPizzaId() <= 0) throw new ServiceException("Selecione um cliente e uma pizza.");
        if (p.getQuantidade() <= 0) throw new ServiceException("A quantidade deve ser maior que zero.");
        if (p.getValorTotal() <= 0) throw new ServiceException("O valor total deve ser maior que zero.");
        if (p.getStatus() == null || p.getStatus().trim().isEmpty()) p.setStatus("Em Andamento");
        if (p.getStatus().length() > 30) throw new ServiceException("O status deve ter no máximo 30 caracteres.");
        if (p.getId() == 0) dao.inseri(p); else dao.alteri(p);
    }
    public void excluir(int id) throws Exception { if (id <= 0) throw new ServiceException("Pedido inválido."); dao.exclui(id); }
}
