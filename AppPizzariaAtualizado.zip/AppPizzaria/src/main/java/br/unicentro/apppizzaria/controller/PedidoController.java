package br.unicentro.apppizzaria.controller;

import br.unicentro.apppizzaria.facade.PedidoFacade;
import br.unicentro.apppizzaria.main.GerenciadorTelas;
import br.unicentro.apppizzaria.model.Cliente;
import br.unicentro.apppizzaria.model.Pedido;
import br.unicentro.apppizzaria.model.Pizza;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class PedidoController {
    @FXML private ComboBox<Cliente> cbCliente;
    @FXML private ComboBox<Pizza> cbPizza;
    @FXML private TextField txtQuantidade;
    @FXML private Label lblValorTotal;
    @FXML private TextField txtStatus;
    @FXML private TextField txtAdicionais;
    @FXML private TableView<Pedido> tablePedidos;
    @FXML private TableColumn<Pedido, Integer> colId;
    @FXML private TableColumn<Pedido, Integer> colCliente;
    @FXML private TableColumn<Pedido, Integer> colPizza;
    @FXML private TableColumn<Pedido, Integer> colQuantidade;
    @FXML private TableColumn<Pedido, Double> colValorTotal;
    @FXML private TableColumn<Pedido, String> colStatus;
    @FXML private TableColumn<Pedido, String> colAdicionais;

    private final PedidoFacade pedidoFacade = new PedidoFacade();
    private Pedido pedidoSelecionado;

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colCliente.setCellValueFactory(new PropertyValueFactory<>("clienteId"));
        colPizza.setCellValueFactory(new PropertyValueFactory<>("pizzaId"));
        colQuantidade.setCellValueFactory(new PropertyValueFactory<>("quantidade"));
        colValorTotal.setCellValueFactory(new PropertyValueFactory<>("valorTotal"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        cbPizza.valueProperty().addListener((obs, antigo, atual) -> calcularTotal());
        txtQuantidade.textProperty().addListener((obs, antigo, atual) -> calcularTotal());
        txtAdicionais.textProperty().addListener((obs, antigo, atual) -> calcularTotal());
        colAdicionais.setCellValueFactory(new PropertyValueFactory<>("adicionais"));
        carregarCombos();
        carregarTabela();

        tablePedidos.getSelectionModel().selectedItemProperty().addListener((obs, antigo, atual) -> {
            if (atual != null) {
                pedidoSelecionado = atual;
                cbCliente.getItems().stream().filter(c -> c.getId() == atual.getClienteId()).findFirst().ifPresent(cbCliente::setValue);
                cbPizza.getItems().stream().filter(p -> p.getId() == atual.getPizzaId()).findFirst().ifPresent(cbPizza::setValue);
                txtQuantidade.setText(String.valueOf(atual.getQuantidade()));
                lblValorTotal.setText(String.format(java.util.Locale.forLanguageTag("pt-BR"), "R$ %.2f", atual.getValorTotal()));
                txtStatus.setText(atual.getStatus());
                txtAdicionais.setText(atual.getAdicionais());
            }
        });
    }

    private void carregarCombos() {
        try {
            cbCliente.setItems(FXCollections.observableArrayList(pedidoFacade.listarClientes()));
            cbPizza.setItems(FXCollections.observableArrayList(pedidoFacade.listarPizzas()));
        } catch (Exception e) {
            Aviso.erro("Não foi possível carregar clientes e pizzas.\n" + e.getMessage());
        }
    }

    private void carregarTabela() {
        try {
            tablePedidos.setItems(FXCollections.observableArrayList(pedidoFacade.listarPedidos()));
        } catch (Exception e) {
            Aviso.erro("Não foi possível carregar pedidos.\n" + e.getMessage());
        }
    }

    @FXML
    public void calcularTotal() {
        try {
            Pizza pizza = cbPizza.getValue();
            int quantidade = Integer.parseInt(txtQuantidade.getText().trim());
            if (pizza != null && quantidade > 0) {
                lblValorTotal.setText(String.format(java.util.Locale.forLanguageTag("pt-BR"), "R$ %.2f", pedidoFacade.calcularTotal(pizza, quantidade, txtAdicionais.getText())));
                return;
            }
        } catch (NumberFormatException ignored) {
        }
        lblValorTotal.setText("R$ 0,00");
    }

    @FXML
    public void salvar() {
        Cliente cliente = cbCliente.getValue();
        Pizza pizza = cbPizza.getValue();
        if (cliente == null || pizza == null) {
            Aviso.erro("Selecione um cliente e uma pizza.");
            return;
        }

        int quantidade;
        try {
            quantidade = Integer.parseInt(txtQuantidade.getText().trim());
            if (quantidade <= 0) {
                Aviso.erro("A quantidade deve ser maior que zero.");
                return;
            }
        } catch (NumberFormatException e) {
            Aviso.erro("Digite uma quantidade inteira válida.");
            return;
        }

        String status = txtStatus.getText().trim();
        if (status.isEmpty()) status = "Em Andamento";
        try {
            int id = pedidoSelecionado == null ? 0 : pedidoSelecionado.getId();
            pedidoFacade.salvarPedido(id, cliente.getId(), pizza.getId(), quantidade, status, txtAdicionais.getText());
            Aviso.mostrar("Sucesso", pedidoSelecionado == null ? "Pedido cadastrado." : "Pedido atualizado.");
            limparCampos();
            carregarTabela();
        } catch (Exception e) {
            Aviso.erro("Não foi possível salvar o pedido.\n" + e.getMessage());
        }
    }

    @FXML
    public void excluir() {
        if (pedidoSelecionado == null) {
            Aviso.erro("Selecione um pedido na tabela para excluir.");
            return;
        }
        try {
            pedidoFacade.excluirPedido(pedidoSelecionado.getId());
            limparCampos();
            carregarTabela();
            Aviso.mostrar("Sucesso", "Pedido excluído.");
        } catch (Exception e) {
            Aviso.erro("Não foi possível excluir o pedido.\n" + e.getMessage());
        }
    }

    @FXML
    public void limparCampos() {
        pedidoSelecionado = null;
        tablePedidos.getSelectionModel().clearSelection();
        cbCliente.setValue(null);
        cbPizza.setValue(null);
        txtQuantidade.clear();
        lblValorTotal.setText("R$ 0,00");
        txtStatus.clear();
        txtAdicionais.clear();
    }

    @FXML
    public void voltar() {
        GerenciadorTelas.trocadeTela("Menus.fxml");
    }
}
