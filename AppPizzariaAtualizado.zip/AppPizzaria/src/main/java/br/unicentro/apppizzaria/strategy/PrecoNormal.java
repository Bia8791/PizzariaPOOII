package br.unicentro.apppizzaria.strategy;
public class PrecoNormal implements PoliticaPreco {
    public double calcular(double valorUnitario, int quantidade) { return valorUnitario * quantidade; }
    public String descricao() { return "Preço normal"; }
}
