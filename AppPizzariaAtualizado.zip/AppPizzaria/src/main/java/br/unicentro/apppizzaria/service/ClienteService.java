package br.unicentro.apppizzaria.service;

import br.unicentro.apppizzaria.dao.ClienteDAO;
import br.unicentro.apppizzaria.dao.IClienteDAO;
import br.unicentro.apppizzaria.model.Cliente;
import java.util.List;

/** Regras e operações de aplicação relacionadas a clientes. */
public class ClienteService {
    private final IClienteDAO dao;
    public ClienteService() { this(new ClienteDAO()); }
    public ClienteService(IClienteDAO dao) { this.dao = dao; }
    public List<Cliente> listar() throws Exception { return dao.buscarTodos(); }
    public List<Cliente> pesquisar(String nome) throws Exception { return dao.buscarPorNome(nome == null ? "" : nome.trim()); }
    public void salvar(Cliente c) throws Exception {
        validar(c);
        if (c.getId() == 0) dao.inseri(c); else dao.alteri(c);
    }
    public void excluir(int id) throws Exception { if (id <= 0) throw new ServiceException("Cliente inválido."); dao.exclui(id); }
    public Cliente obter(int id) throws Exception {
        return dao.buscarTodos().stream().filter(c -> c.getId() == id).findFirst()
                .orElseThrow(() -> new ServiceException("Cliente não encontrado."));
    }
    private void validar(Cliente c) throws ServiceException {
        if (c == null || vazio(c.getNome()) || vazio(c.getTelefone()) || vazio(c.getEndereco()))
            throw new ServiceException("Preencha nome, telefone e endereço do cliente.");
    }
    private boolean vazio(String s) { return s == null || s.trim().isEmpty(); }
}
