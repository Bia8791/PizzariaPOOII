package br.unicentro.apppizzaria.decorator;
/** Componente do Decorator: representa algo que possui preço calculável. */
public interface PrecoPizza { double calcularPreco(); }
