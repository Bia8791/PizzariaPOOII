package br.unicentro.apppizzaria.service;

import br.unicentro.apppizzaria.dao.IPizzaDAO;
import br.unicentro.apppizzaria.dao.PizzaDAO;
import br.unicentro.apppizzaria.model.Pizza;
import java.util.List;

/** Regras e operações de aplicação relacionadas ao cardápio. */
public class PizzaService {
    private final IPizzaDAO dao;
    public PizzaService() { this(new PizzaDAO()); }
    public PizzaService(IPizzaDAO dao) { this.dao = dao; }
    public List<Pizza> listar() throws Exception { return dao.buscarTodos(); }
    public Pizza obter(int id) throws Exception {
        return dao.buscarTodos().stream().filter(p -> p.getId() == id).findFirst()
                .orElseThrow(() -> new ServiceException("Pizza não encontrada."));
    }
    public void salvar(Pizza p) throws Exception {
        if (p == null || p.getNome() == null ||
                p.getNome().trim().isEmpty() ||
                p.getIngredientes() == null ||
                p.getIngredientes().trim().isEmpty())
            throw new ServiceException("Informe o nome e os ingredientes da pizza.");
        if (p.getPreco() <= 0) throw new ServiceException("O preço deve ser maior que zero.");
        if (p.getId() == 0) dao.inseri(p);
        else dao.alteri(p);
    }
    public void excluir(int id) throws Exception { if (id <= 0) throw new ServiceException("Pizza inválida."); dao.exclui(id); }
}
