module br.unicentro.apppizzaria {
    requires javafx.controls;
    requires javafx.fxml;


    opens br.unicentro.apppizzaria to javafx.fxml;
    exports br.unicentro.apppizzaria;
}