-- Script de criação do Banco de Dados para a Pizzaria
CREATE DATABASE pizzaria_db;

-- Tabela Cliente
CREATE TABLE cliente (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    endereco VARCHAR(200) NOT NULL
);

-- Tabela Pizza
CREATE TABLE pizza (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    ingredientes TEXT NOT NULL,
    preco NUMERIC(10,2) NOT NULL
);

-- Tabela Pedido
CREATE TABLE pedido (
    id SERIAL PRIMARY KEY,
    cliente_id INT NOT NULL REFERENCES cliente(id) ON DELETE CASCADE,
    pizza_id INT NOT NULL REFERENCES pizza(id) ON DELETE CASCADE,
    quantidade INT NOT NULL DEFAULT 1,
    valor_total NUMERIC(10,2) NOT NULL,
    status VARCHAR(30) DEFAULT 'Em Andamento'
);
