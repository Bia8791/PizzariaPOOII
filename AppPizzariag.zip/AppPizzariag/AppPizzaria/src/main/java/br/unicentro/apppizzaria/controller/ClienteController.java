package br.unicentro.apppizzaria.controller;

import br.unicentro.apppizzaria.dao.ClienteDAO;
import br.unicentro.apppizzaria.main.GerenciadorTelas;
import br.unicentro.apppizzaria.model.Cliente;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class ClienteController {

    @FXML private TextField txtNome;
    @FXML private TextField txtTelefone;
    @FXML private TextField txtEndereco;
    @FXML private TableView<Cliente> tableClientes;
    @FXML private TableColumn<Cliente, Integer> colId;
    @FXML private TableColumn<Cliente, String> colNome;
    @FXML private TableColumn<Cliente, String> colTelefone;
    @FXML private TableColumn<Cliente, String> colEndereco;

    private ClienteDAO clienteDAO = new ClienteDAO();
    private Cliente clienteSelecionado;

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colTelefone.setCellValueFactory(new PropertyValueFactory<>("telefone"));
        colEndereco.setCellValueFactory(new PropertyValueFactory<>("endereco"));
        carregarTabela();

        tableClientes.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                clienteSelecionado = newVal;
                txtNome.setText(newVal.getNome());
                txtTelefone.setText(newVal.getTelefone());
                txtEndereco.setText(newVal.getEndereco());
            }
        });
    }

    private void carregarTabela() {
        try {
            ObservableList<Cliente> clientes = FXCollections.observableArrayList(clienteDAO.buscarTodos());
            tableClientes.setItems(clientes);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void salvar() {
        try {
            if (clienteSelecionado == null) {
                Cliente c = new Cliente(txtNome.getText(), txtTelefone.getText(), txtEndereco.getText());
                clienteDAO.inseri(c);
            } else {
                clienteSelecionado.setNome(txtNome.getText());
                clienteSelecionado.setTelefone(txtTelefone.getText());
                clienteSelecionado.setEndereco(txtEndereco.getText());
                clienteDAO.alteri(clienteSelecionado);
            }
            limparCampos();
            carregarTabela();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void excluir() {
        try {
            if (clienteSelecionado != null) {
                clienteDAO.exclui(clienteSelecionado.getId());
                limparCampos();
                carregarTabela();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void limparCampos() {
        clienteSelecionado = null;
        txtNome.clear();
        txtTelefone.clear();
        txtEndereco.clear();
    }

    @FXML
    public void voltar() {
        GerenciadorTelas.trocadeTela("Menus.fxml");
    }
}
