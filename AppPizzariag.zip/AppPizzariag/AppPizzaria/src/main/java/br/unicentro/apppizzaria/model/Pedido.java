package br.unicentro.apppizzaria.model;

public class Pedido {
    private int id;
    private int clienteId;
    private int pizzaId;
    private int quantidade;
    private double valorTotal;
    private String status;

    public Pedido() {}

    public Pedido(int id, int clienteId, int pizzaId, int quantidade, double valorTotal, String status) {
        this.id = id;
        this.clienteId = clienteId;
        this.pizzaId = pizzaId;
        this.quantidade = quantidade;
        this.valorTotal = valorTotal;
        this.status = status;
    }

    public Pedido(int clienteId, int pizzaId, int quantidade, double valorTotal, String status) {
        this.clienteId = clienteId;
        this.pizzaId = pizzaId;
        this.quantidade = quantidade;
        this.valorTotal = valorTotal;
        this.status = status;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getClienteId() { return clienteId; }
    public void setClienteId(int clienteId) { this.clienteId = clienteId; }
    public int getPizzaId() { return pizzaId; }
    public void setPizzaId(int pizzaId) { this.pizzaId = pizzaId; }
    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }
    public double getValorTotal() { return valorTotal; }
    public void setValorTotal(double valorTotal) { this.valorTotal = valorTotal; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
