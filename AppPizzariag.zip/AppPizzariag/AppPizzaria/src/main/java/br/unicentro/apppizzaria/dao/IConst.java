package br.unicentro.apppizzaria.dao;

public interface IConst {
    String DRIVER = "org.postgresql.Driver";
    String URL = "jdbc:postgresql://localhost:5432/pizzaria_db";
    String USER = "postgres";
    String PWD = "postgres";
}
