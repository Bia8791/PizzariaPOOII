package br.unicentro.apppizzaria.controller;

import br.unicentro.apppizzaria.dao.ClienteDAO;
import br.unicentro.apppizzaria.dao.PedidoDAO;
import br.unicentro.apppizzaria.dao.PizzaDAO;
import br.unicentro.apppizzaria.main.GerenciadorTelas;
import br.unicentro.apppizzaria.model.Cliente;
import br.unicentro.apppizzaria.model.Pedido;
import br.unicentro.apppizzaria.model.Pizza;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class PedidoController {

    @FXML private ComboBox<Cliente> cbCliente;
    @FXML private ComboBox<Pizza> cbPizza;
    @FXML private TextField txtQuantidade;
    @FXML private Label lblValorTotal;
    @FXML private TextField txtStatus;
    @FXML private TableView<Pedido> tablePedidos;
    @FXML private TableColumn<Pedido, Integer> colId;
    @FXML private TableColumn<Pedido, Integer> colCliente;
    @FXML private TableColumn<Pedido, Integer> colPizza;
    @FXML private TableColumn<Pedido, Integer> colQuantidade;
    @FXML private TableColumn<Pedido, Double> colValorTotal;
    @FXML private TableColumn<Pedido, String> colStatus;

    private PedidoDAO pedidoDAO = new PedidoDAO();
    private ClienteDAO clienteDAO = new ClienteDAO();
    private PizzaDAO pizzaDAO = new PizzaDAO();
    private Pedido pedidoSelecionado;

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colCliente.setCellValueFactory(new PropertyValueFactory<>("clienteId"));
        colPizza.setCellValueFactory(new PropertyValueFactory<>("pizzaId"));
        colQuantidade.setCellValueFactory(new PropertyValueFactory<>("quantidade"));
        colValorTotal.setCellValueFactory(new PropertyValueFactory<>("valorTotal"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        carregarCombos();
        carregarTabela();

        tablePedidos.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                pedidoSelecionado = newVal;
                txtQuantidade.setText(String.valueOf(newVal.getQuantidade()));
                lblValorTotal.setText(String.format("R$ %.2f", newVal.getValorTotal()));
                txtStatus.setText(newVal.getStatus());
            }
        });
    }

    private void carregarCombos() {
        try {
            cbCliente.setItems(FXCollections.observableArrayList(clienteDAO.buscarTodos()));
            cbPizza.setItems(FXCollections.observableArrayList(pizzaDAO.buscarTodos()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void carregarTabela() {
        try {
            ObservableList<Pedido> pedidos = FXCollections.observableArrayList(pedidoDAO.buscarTodos());
            tablePedidos.setItems(pedidos);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void calcularTotal() {
        try {
            Pizza p = cbPizza.getValue();
            int qtd = Integer.parseInt(txtQuantidade.getText());
            if (p != null && qtd > 0) {
                double total = p.getPreco() * qtd;
                lblValorTotal.setText(String.format("R$ %.2f", total));
            }
        } catch (Exception e) {
            lblValorTotal.setText("R$ 0,00");
        }
    }

    @FXML
    public void salvar() {
        try {
            Cliente c = cbCliente.getValue();
            Pizza p = cbPizza.getValue();
            int qtd = Integer.parseInt(txtQuantidade.getText());
            double total = p.getPreco() * qtd;
            String status = txtStatus.getText().isEmpty() ? "Em Andamento" : txtStatus.getText();

            if (pedidoSelecionado == null) {
                Pedido ped = new Pedido(c.getId(), p.getId(), qtd, total, status);
                pedidoDAO.inseri(ped);
            } else {
                pedidoSelecionado.setClienteId(c.getId());
                pedidoSelecionado.setPizzaId(p.getId());
                pedidoSelecionado.setQuantidade(qtd);
                pedidoSelecionado.setValorTotal(total);
                pedidoSelecionado.setStatus(status);
                pedidoDAO.alteri(pedidoSelecionado);
            }
            limparCampos();
            carregarTabela();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void excluir() {
        try {
            if (pedidoSelecionado != null) {
                pedidoDAO.exclui(pedidoSelecionado.getId());
                limparCampos();
                carregarTabela();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void limparCampos() {
        pedidoSelecionado = null;
        cbCliente.setValue(null);
        cbPizza.setValue(null);
        txtQuantidade.clear();
        lblValorTotal.setText("R$ 0,00");
        txtStatus.clear();
    }

    @FXML
    public void voltar() {
        GerenciadorTelas.trocadeTela("Menus.fxml");
    }
}
