package br.unicentro.apppizzaria.controller;

import br.unicentro.apppizzaria.dao.PizzaDAO;
import br.unicentro.apppizzaria.main.GerenciadorTelas;
import br.unicentro.apppizzaria.model.Pizza;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class PizzaController {

    @FXML private TextField txtNome;
    @FXML private TextField txtIngredientes;
    @FXML private TextField txtPreco;
    @FXML private TableView<Pizza> tablePizzas;
    @FXML private TableColumn<Pizza, Integer> colId;
    @FXML private TableColumn<Pizza, String> colNome;
    @FXML private TableColumn<Pizza, String> colIngredientes;
    @FXML private TableColumn<Pizza, Double> colPreco;

    private PizzaDAO pizzaDAO = new PizzaDAO();
    private Pizza pizzaSelecionada;

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colIngredientes.setCellValueFactory(new PropertyValueFactory<>("ingredientes"));
        colPreco.setCellValueFactory(new PropertyValueFactory<>("preco"));
        carregarTabela();

        tablePizzas.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                pizzaSelecionada = newVal;
                txtNome.setText(newVal.getNome());
                txtIngredientes.setText(newVal.getIngredientes());
                txtPreco.setText(String.valueOf(newVal.getPreco()));
            }
        });
    }

    private void carregarTabela() {
        try {
            ObservableList<Pizza> pizzas = FXCollections.observableArrayList(pizzaDAO.buscarTodos());
            tablePizzas.setItems(pizzas);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void salvar() {
        try {
            double preco = Double.parseDouble(txtPreco.getText());
            if (pizzaSelecionada == null) {
                Pizza p = new Pizza(txtNome.getText(), txtIngredientes.getText(), preco);
                pizzaDAO.inseri(p);
            } else {
                pizzaSelecionada.setNome(txtNome.getText());
                pizzaSelecionada.setIngredientes(txtIngredientes.getText());
                pizzaSelecionada.setPreco(preco);
                pizzaDAO.alteri(pizzaSelecionada);
            }
            limparCampos();
            carregarTabela();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void excluir() {
        try {
            if (pizzaSelecionada != null) {
                pizzaDAO.exclui(pizzaSelecionada.getId());
                limparCampos();
                carregarTabela();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void limparCampos() {
        pizzaSelecionada = null;
        txtNome.clear();
        txtIngredientes.clear();
        txtPreco.clear();
    }

    @FXML
    public void voltar() {
        GerenciadorTelas.trocadeTela("Menus.fxml");
    }
}
